import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from retailer_locator import consolidate, extract_stores, spreadsheet_safe

BASE = Path(__file__).parent


class LocatorTests(unittest.TestCase):
    def test_fixture(self):
        with (BASE / "fixtures/store_locations.json").open() as source:
            rows = extract_stores(json.load(source))
        self.assertEqual(len(rows), 5)
        retailers, locations, review = consolidate(rows)
        self.assertEqual(len(locations), 4)
        self.assertEqual([r["branch_count"] for r in retailers], [2, 1, 1])
        self.assertEqual(retailers[0]["single_branch_address"], "")
        self.assertIn("Unit 2", retailers[1]["single_branch_address"])
        self.assertEqual(locations[0]["postal_code"], "00501")
        self.assertEqual([r["missing_fields"] for r in review], ["street"])
        self.assertEqual(extract_stores({"items": [{"name": "Not a location"}]}), [])

    def test_allowlist_and_formula(self):
        _, branches, _ = consolidate([{"name": "=A1", "city": "Example", "email": "discarded", "id": "discarded"}])
        self.assertNotIn("email", branches[0])
        self.assertNotIn("id", branches[0])
        self.assertEqual(spreadsheet_safe(branches[0]["store"]), "'=A1")

    def test_cli(self):
        with tempfile.TemporaryDirectory() as d:
            result = subprocess.run([sys.executable, str(BASE / "retailer_locator.py"), "--json",
                                     str(BASE / "fixtures/store_locations.json"), "--output", d],
                                    capture_output=True, text=True, check=True)
            self.assertIn("1 duplicates removed", result.stdout)
            self.assertEqual({p.name for p in Path(d).iterdir()},
                             {"retailers.csv", "locations.csv", "missing_information.csv"})
            with (Path(d) / "retailers.csv").open(encoding="utf-8-sig") as exported:
                self.assertEqual(len(list(csv.DictReader(exported))), 3)


if __name__ == "__main__":
    unittest.main()
