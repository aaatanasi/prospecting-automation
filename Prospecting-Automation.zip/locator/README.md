# Store Locator Parser

This portfolio edition turns a local JSON export of storefront listings into a retailer list, a location-level file, and a missing-information review file. It illustrates the data preparation step between source collection and prospect research, without connecting to an external service.

## Run

Requires Python 3.9+; no third-party packages.

```sh
python3 retailer_locator.py --json fixtures/store_locations.json --output ./locator_exports
PYTHONDONTWRITEBYTECODE=1 python3 -m unittest -v
```

| Output | What it includes |
| --- | --- |
| `retailers.csv` | One row per retailer, branch count, and distinct branch locations |
| `locations.csv` | Name and normalized business-address fields for each branch |
| `missing_information.csv` | Locations missing street, city, or country |

The parser looks for the largest list of store-shaped records in a nested payload. It supports alternate name and street fields, removes duplicate branches, and uses explicit aliases to combine branch names. For a multi-location retailer, the single-branch address is left blank. The supplied fixture contains only fictional storefronts. Email, phone, source IDs, and websites are not exported. The tool reads and writes local files only; it neither retrieves source data nor imports results into another system. JSON schemas that differ substantially may need their own adapter.
