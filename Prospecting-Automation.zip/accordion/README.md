# Expandable Directory Parser

This portfolio edition keeps the original HTML parsing logic for expandable directory sections. It reads a saved local HTML file, recognizes bold organization names and location lines, and exports a CSV. Missing cities are marked for review. Network fetching, contact fields, and original examples are not included.

From this folder, run:

```sh
python3 accordion_directory.py fixtures/directory.html organizations.csv
```

Requires Python 3.9 or later and no additional packages. The included example contains fictional organizations only. The parser expects the example accordion markup; it is not a universal directory parser.
