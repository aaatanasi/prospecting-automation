# Prospecting Automation

Three Python scripts I developed to turn different public listing formats into structured records for prospect research and CRM import review.

| Source | Parser | Output |
| --- | --- | --- |
| Expandable HTML directory | [Accordion parser](accordion/README.md) | Organization, location, source, and missing-location review |
| Text-based HTML listings | [Text parser](text/README.md) | Import-shaped CSV and separate review rows |
| Map-based locator data | [Location parser](locator/README.md) | Organization rollup, unique locations, and incomplete-location review |

Open [the visual overview](index.html) in a browser. Each folder's README has a command to try the parser with its own sample input. All three run locally on Python 3.9 or newer without third-party dependencies.

The code is based on real projects I developed. The records shown are fictional to protect client confidentiality. This edition uses saved example inputs only. It has no live website collection or CRM connection. Review and map fields before importing anything into an actual CRM.
