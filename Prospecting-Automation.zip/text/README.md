# Text Stockist Extractor

This portfolio edition is derived from a Python extractor I built to turn public text-based brand stockist pages into structured retailer prospects for a proposed Close CRM import. It separates ambiguous records for human review rather than treating a heuristic match as verified data.

## What it does

- Prioritizes the primary HTML content, skipping navigation and other page chrome.
- Recognizes the common retailer name → address → contact pattern. Contact lines act as record boundaries, with review flags for missing addresses, uncertain locations, long chunks, and trailing unparsed text.
- Keeps distinct store locations and deduplicates only a matching name and address.
- Outputs an import-shaped CSV and a second CSV containing only flagged rows. Review all results and map fields before any actual import.

The original script fetched pages and exported a styled Excel workbook with **Close Import** and **Review** tabs plus a CSV. This edition reads local HTML and writes two CSVs using the Python standard library. It uses a source filename instead of a live source URL, opens no websites, and does not connect to Close or write to a CRM. The fixture and example outputs are entirely fictional; reserved `.invalid` domains are placeholders.

## Run locally

Requires Python 3.9+. From this directory:

```sh
python3 stockists_to_close.py fixtures/stockists.html --output output
python3 -B -m unittest discover -s tests -v
```

Compare the generated files with [the import example](examples/close_import.csv) and [the review example](examples/review.csv). A contact boundary is useful on simple layouts, but this approach does not render JavaScript, geocode locations, or independently validate contact information.
