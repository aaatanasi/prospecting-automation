import csv
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
import unittest

from stockists_to_close import HEADERS, Page, extract, safe_cell

ROOT = Path(__file__).resolve().parents[1]
FIXTURE = ROOT / "fixtures" / "stockists.html"


class ParserTests(unittest.TestCase):
    def fixture_rows(self):
        page = Page()
        page.feed(FIXTURE.read_text(encoding="utf-8"))
        page.close()
        self.assertEqual(page.brand_name(), "Fictional Atelier")
        self.assertNotIn("Unrelated page menu", page.lines())
        self.assertNotIn("Private storefront links deliberately excluded", page.lines())
        return extract(page.lines(), page.brand_name(), FIXTURE.name)

    def test_fields_and_deduplication(self):
        rows = self.fixture_rows()
        self.assertEqual(len(rows), 4)
        self.assertEqual([(r["Company"], r["City"], r["State"], r["Zip"], r["Country"])
                          for r in rows[:2]], [
            ("Willow Sample House", "Sample City", "NY", "00001", "United States"),
            ("Willow Sample House", "Sample City", "NY", "00001", "United States"),
        ])
        self.assertNotEqual(rows[0]["Address"], rows[1]["Address"])
        self.assertTrue(all(not r["Phone"] and not r["Email"] for r in rows))
        self.assertTrue(all(r["URL"].endswith(".invalid") for r in rows))

    def test_review(self):
        rows = self.fixture_rows()
        self.assertEqual([r["Company"] for r in rows if r["Review"]],
                         ["Morrow Sample Studio", "Silver Thread Sample Shop"])
        self.assertIn("Check location fields", rows[2]["Review"])
        self.assertIn("Online/no address", rows[3]["Review"])
        self.assertIn("Unparsed trailing text", rows[3]["Review"])

    def test_first_party_field_source_and_csv_examples(self):
        with TemporaryDirectory() as directory:
            run = subprocess.run(
                [sys.executable, "-B", str(ROOT / "stockists_to_close.py"),
                 str(FIXTURE), "--output", directory],
                check=True, text=True, capture_output=True)
            self.assertIn("4 possible stockists; 2 flagged", run.stdout)
            for name, count in [("close_import.csv", 4), ("review.csv", 2)]:
                path = Path(directory) / name
                self.assertEqual(path.read_bytes(), (ROOT / "examples" / name).read_bytes())
                with path.open(encoding="utf-8-sig", newline="") as f:
                    read = csv.DictReader(f)
                    self.assertEqual(read.fieldnames, HEADERS)
                    self.assertEqual(len(list(read)), count)

    def test_title_fallback_and_focus(self):
        page = Page()
        page.feed("<head><title>Stockists | Fictional Label</title></head>"
                  "<body><div>Outer</div><div role='main'><p>Inner</p></div></body>")
        self.assertEqual(page.brand_name(), "Fictional Label")
        self.assertEqual(page.lines(), ["Inner"])

    def test_spreadsheet_guard(self):
        self.assertEqual(safe_cell(" =1+1"), "' =1+1")
        self.assertEqual(safe_cell("00001"), "00001")


if __name__ == "__main__":
    unittest.main()
